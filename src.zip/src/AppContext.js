import { createContext } from "react";

const AppContext= createContext(null);

export default AppContext;