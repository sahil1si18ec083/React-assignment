const  appLogo="https://assets-global.website-files.com/63e3da3df35cd62f54751985/649488c838360d22ac08b864_bill-logo.svg"

export {appLogo}