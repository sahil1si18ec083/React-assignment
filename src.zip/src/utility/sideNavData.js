const sideNavContents = [
    { label: "Analytics", visible: true },
    {
        label: "Invoice Reports", visible: true
    },
];
export default sideNavContents;
