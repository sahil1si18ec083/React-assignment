import ListViewTable from "./ListViewTable";
import TablePagination from "@mui/material/TablePagination";
import InvoiceReportsJson from "../../utility/invoiceReports.json";
import { useContext } from "react";
import ListViewHeader from "./ListViewHeader";
import AppContext from "../../AppContext";
const InvoiceReports = () => {
  const totalRecords = InvoiceReportsJson.totalRecords;
  const appContext = useContext(AppContext);
  const listPage = appContext.listPage;
  const handlePageChange = (oEvent, newPage) => {
    appContext.setpageno(newPage);
  };
  return (
    <>
      <ListViewHeader  />

      <ListViewTable />
      <TablePagination
        className="sticky-pagination"
        rowsPerPageOptins={[]}
        component="div"
        count={totalRecords}
        rowsPerPage={50}
        page={listPage}
        onPageChange={handlePageChange}
      />
    </>
  );
};
export default InvoiceReports;
