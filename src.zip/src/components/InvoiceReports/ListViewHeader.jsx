import React from "react";
import GridViewIcon from "@mui/icons-material/GridView";
import ListIcon from "@mui/icons-material/List";
import SortingPopover from "./SortingPopover";
const ListViewHeader = ({
  moduleMetadata,
  gridViewFlag,
  splitScreen,
  onSelectGridorListViewChangeHandler,
}) => {
  
  return (
    <header className="listHeader">
      {/* <h3>{moduleMetadata?.moduleName}</h3> */}
      <div className="actionButtons">
        hi
      
      <SortingPopover
            // payload={oPayload}
            // setPayload={setPayload}
            // setPage={setPage}
            // sortBy={sortBy}
            // setSortBy={setSortBy}
            // sortingOrder={sortingOrder}
            // setSortingOrder={setSortingOrder}
          />
      </div>
    </header>
  );
};

export default ListViewHeader;

