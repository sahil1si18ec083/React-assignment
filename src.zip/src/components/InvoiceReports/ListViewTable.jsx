import React from "react";
import CustomTable from "../CustomComponents/CustomTable";
import InvoiceReportsJson from "../../utility/invoiceReports.json";
import { moduleListFields } from "../../utility/config";
import AppContext from "../../AppContext";
import { useContext } from "react";
const ListViewTable = () => {
  const appContext = useContext(AppContext);
  const currentModule = appContext.currentModule;
  const defaultModuleColumns = moduleListFields
    .filter((moduleData) => {
      return moduleData.moduleName === currentModule;
    })
    ?.at(0)?.columnsList;
  return (
    <div>
      <CustomTable
        Headercolumns={defaultModuleColumns}
        rows={InvoiceReportsJson?.data}
      />
    </div>
  );
};

export default ListViewTable;
